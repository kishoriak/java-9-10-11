package org.appsweaver.experiments.easily_handle_emoji_unicode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @author udhansingh
 *
 */
@SpringBootApplication
public class EasilyHandleEmojiUnicodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasilyHandleEmojiUnicodeApplication.class, args);
	}
}
